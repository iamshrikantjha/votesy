import React, { Component } from 'react';
import { Text, View,
    TouchableHighlight, TouchableOpacity, TouchableNativeFeedback, TouchableWithoutFeedback, Dimensions  } from 'react-native';

import * as firebase from 'firebase';
// import { Vote } from './Vote';
import {
    PieChart,
  } from 'react-native-chart-kit'

class Dashboard extends Component {
    constructor(props){
        super(props)
        // this.state = ({

        // })
    }

    checkvote = () => {
        console.log('Start Checking')
        // console.log(this.state.name);
        // var name = this.state.name;
        var userId = firebase.auth().currentUser.uid;
        firebase.database().ref('user/'+userId).once('value', function(snapshot){
            if (snapshot.val().voted==1)
            {
                alert("Sorry you cannot vote because you have already voted.");
                // this.props.navigation.navigate('Vote');
                return;
            }
            else {
                console.log("Checking Closed Eligible");
                console.log('Redirecting to next screen');
                navigation.navigate('Vote');
                console.log('Redirection Completed')
                return;
            }
        })
    }
    logOutUser = () => {
        firebase.auth().signOut().then(function() {
            console.log('Logged Out');
            // this.setState={this.props.navigation.navigate('Login')}
          }, function(error) {
            console.log('Error');
          });
           
    }
        

  render() {

    const data = [
        { name: 'BJP', population: 215, color: 'rgba(131, 167, 234, 1)', legendFontColor: '#7F7F7F', legendFontSize: 10 },
        { name: 'AAP', population: 28, color: '#F00', legendFontColor: '#7F7F7F', legendFontSize: 10 },
        { name: 'CONG', population: 5, color: 'red', legendFontColor: '#7F7F7F', legendFontSize: 10 },
        { name: 'SPA', population: 8, color: 'green', legendFontColor: '#7F7F7F', legendFontSize: 10 },
        { name: 'NDA', population: 119, color: 'rgb(0, 0, 255)', legendFontColor: '#7F7F7F', legendFontSize: 10 }
      ]
      const chartConfig = {
        backgroundGradientFrom: '#1E2923',
        backgroundGradientTo: '#08130D',
        color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
        strokeWidth: 1 // optional, default 3
      }
    return (
        <View style={{
            flex: 1,
            flexDirection: "column",
        }}>
        <View style={{
            flex: 1,
            backgroundColor: '#94e3f7',
            justifyContent: "flex-end",
        }}>
        {/* Text */}

        <Text style={{
            fontSize: 40,
            fontWeight: "500",
            color: "#2eb2d6",
            marginBottom: 50,
            marginLeft: 25,
        }}>
            Dashboard
        </Text>

        </View>
        
        
            <View style={{
                flex: 2,
                backgroundColor: "white",
                alignItems: "center",
            }}>
                {/* This function is our Dashboardbutton */}
                <TouchableOpacity onPress={() => this.checkvote()}>
                <View style={{
                    flexDirection: "row",
                    margin: 30,
                    width: 300,
                    height: 70,
                    borderRadius: 7,
                    elevation: 7,
                    backgroundColor: '#94e3f7',
                    alignItems: "center",
                }}>
                    <Text style={{
                        paddingLeft: 20,
                        flex: 1,
                        fontSize: 20,
                        fontWeight: "bold",
                        color: "#2eb2d6",
                    }}>
                        Vote for your country now !
                    </Text>

                </View>
                </TouchableOpacity>

                <View style={{
                    flex:1,
                    height: 400,
                    // backgroundColor: 'pink',
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 10,
                }}>
                    <PieChart
                    data={data}
                    width={300}
                    height={220}
                    chartConfig={chartConfig}
                    accessor="population"
                    backgroundColor="transparent"
                    paddingLeft="15"
                    absolute
                    />
                </View> 

                {/* Button */}
                <TouchableOpacity onPress={() => {this.logOutUser();this.props.navigation.navigate('Login')}}>
                <View style={{
                        flexDirection: "row",    
                        width: 250,
                        height: 40,
                        marginTop: 50,
                        marginBottom: 40,
                        backgroundColor: "#2eb2d6",
                        borderRadius: 30,
                        alignItems: "center",
                        justifyContent: "center",
                        elevation: 5,
                    }}>
                        <Text style={{
                            width: 100,
                            // alignItems: "center",
                            // backgroundColor: "orange",
                            flexDirection: "row",
                            fontWeight: "bold",
                            fontSize: 15,
                            color: "white",
                            paddingLeft: 15,             
                        }}>
                            Sign Out
                        </Text>
                    </View>
                </TouchableOpacity>   
            </View>
        </View>
    )
  }
}

export default Dashboard;