import React, { Component } from 'react';
import { View, Text, Image, Button, ScrollView, Alert,
    TouchableHighlight, TouchableOpacity, TouchableNativeFeedback, TouchableWithoutFeedback } from 'react-native';


import VCard  from './VCard';
import * as firebase from 'firebase';
// import console = require('console');

class Vote extends React.Component {
  constructor(props){
      super(props) 
      this.state = ({
            name:'',
      }) 
}
    // checkvote = (name) => {
    //     console.log('Start Checking')
    //     console.log(this.state.name);
    //     var name = this.state.name;
    //     var userId = firebase.auth().currentUser.uid;
    //     firebase.database().ref('user/'+userId).once('value', function(snapshot){
    //         if (snapshot.val().voted==1)
    //         {
    //             alert("Sorry you cannot vote because you have already voted.")
    //             return;
    //         }
    //         else {
    //             console.log("Checking Closed Eligible");
    //             alert(name);
    //             console.log('Started voting')
                
    //             // var name = this.state.name;
    //             var ref = firebase.database().ref('candid/'+ name +'/votes');   
    //             ref.transaction(function(currentClicks, name) {
    //             // If node/clicks has never been set, currentRank will be `null`.
    //             console.log('Voting function')
    //             return (currentClicks || 0) + 1;
    //             });
    //         }
    //     })
    // }
    // letsvote=(name)=>{
                
    // }

    // combined(name){
    //     this.checkvote();
    //     this.letsvote();
    // }
    
  render() {
    return (
      <View style={{
          flex: 1,
      }}>
            <View style={{
                flex: 1,
                backgroundColor: "#94e3f7",
                flexDirection: "row",
                alignItems: "flex-end",
            }}>
                <Text style={{
                    fontSize: 30,
                    fontWeight: "500",
                    color: "#2eb2d6",
                    marginBottom: 50,
                    marginLeft: 25,
                }}>
                    Which political party would you like to vote?
                </Text>

            </View>
            <View style={{
                flexDirection: "column",
                flex: 2,
                // backgroundColor: "pink",
                alignItems: "center",
                // elevation: 7,
            }}>
            
            <ScrollView showsVerticalScrollIndicator={false}>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='BJP' image={require('../assets/bjp.png')} onTouch={() => {this.checkvote(this.setState({name: "BJP"}))}}/>
            </TouchableHighlight>
            {/* ,this.checkvote();this.letsvote() */}
            {/* this.flush(this.setState({name: "BJP"})) */}
            {/* ;this.votesy(this.setState({name: "BJP"})) */}
            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='CONG' image={require('../assets/cong.png')} onTouch={() => {this.canvote();this.votesy(this.setState({name: "CONG"}))}}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='AAP' image={require('../assets/aap.jpg')} onTouch={() => {this.canvote();this.votesy(this.setState({name: "AAP"}))}}/>
            </TouchableHighlight>

            {/* <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='BJP' image={require('../assets/bjp.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='CONG' image={require('../assets/cong.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='AAP' image={require('../assets/aap.jpg')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='BJP' image={require('../assets/bjp.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='CONG' image={require('../assets/cong.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='AAP' image={require('../assets/aap.jpg')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='BJP' image={require('../assets/bjp.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='CONG' image={require('../assets/cong.png')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight>

            <TouchableHighlight onPress={this._onPressButton} underlayColor="white">
            <VCard name='AAP' image={require('../assets/aap.jpg')} onTouch={()=>Alert.alert('You tapped the button!')}/>
            </TouchableHighlight> */}
            
            </ScrollView>
            <View style={{
                height: 30,
            }}>
            </View>   
                

            </View>
      </View>
    );
  }
}

export default Vote;
